//
//  Ble.swift
//  LRF OTA Updater (iOS)
//
//  CoreBluetooth 封装。对应安卓的 OtaManager.GattSession + 扫描部分。
//
//  和安卓的几处关键差异（都跟 iOS 的脾气有关，不是随便写的）：
//    · 没有 MAC 地址，设备身份是 CBCentralManager 给的 identifier（UUID 字符串）；
//      同一台外设在同一个 App 里 identifier 稳定，重启后也不变，所以"等设备
//      重启进 OTA"照样能靠它找回同一个 CBPeripheral。
//    · 拿不到 MTU。用 maximumWriteValueLength(for: .withoutResponse) 反推：
//      maxWrite 通常 = MTU - 3。
//    · 无响应写没有 didWriteValueFor 回调，流控只能靠 canSendWriteWithoutResponse
//      + peripheralIsReady(toSendWriteWithoutResponse:) —— 这是 iOS 版的
//      "GATT device busy"，比安卓那套指数退避更准。
//    · iOS 会把扫描缓存回放一遍，刚触发重启时还会报旧名字，所以起扫后
//      头 0.8 秒的广播一律不认（对应安卓的 1.2 秒）。
//

import Foundation
import Combine
import CoreBluetooth

enum BleUUID {
    static let appService = CBUUID(string: "FFE0")   // 普通固件的服务
    static let appChar3   = CBUUID(string: "FFE3")   // 写 1 字节 → 设备重启进 OTA
    static let otaService = CBUUID(string: "FEE0")   // IAP 的服务
    static let otaChar    = CBUUID(string: "FEE1")   // OTA 命令通道（只有 READ / WRITE，没有 CCCD）
}

struct BleDevice: Identifiable, Equatable {
    let id: UUID
    let name: String
    let rssi: Int
    /// 界面上显示的短 ID（安卓显示 MAC，iOS 只能显示 identifier 前 8 位）
    var shortId: String { String(id.uuidString.prefix(8)) }
}

// MARK: - 扫描 / 连接管理

final class BleCentral: NSObject, CBCentralManagerDelegate {

    private var central: CBCentralManager!
    private var peripheralCache: [UUID: CBPeripheral] = [:]
    private var sessions: [UUID: BleSession] = [:]
    private var waiter: ScanWaiter?
    private var scanning = false
    private let maxDevices = 30

    private(set) var state: CBManagerState = .unknown
    private(set) var devices: [BleDevice] = []

    var onStateChange: ((CBManagerState) -> Void)?
    var onDevicesChange: (([BleDevice]) -> Void)?

    private final class ScanWaiter {
        let id: UUID
        let start: Date
        let cont: CheckedContinuation<(CBPeripheral, String)?, Never>
        init(id: UUID, start: Date, cont: CheckedContinuation<(CBPeripheral, String)?, Never>) {
            self.id = id
            self.start = start
            self.cont = cont
        }
    }

    override init() {
        super.init()
        central = CBCentralManager(delegate: self, queue: .main,
                                   options: [CBCentralManagerOptionShowPowerAlertKey: true])
    }

    var isReady: Bool { state == .poweredOn }

    var stateText: String {
        switch state {
        case .poweredOn:    return "Bluetooth ready"
        case .poweredOff:   return "Bluetooth is off - turn it on in Settings"
        case .unauthorized: return "Bluetooth permission denied - allow it in Settings > LRF OTA"
        case .unsupported:  return "This device does not support Bluetooth LE"
        case .resetting:    return "Bluetooth is resetting..."
        default:            return "Bluetooth is unavailable"
        }
    }

    // MARK: 列表扫描

    func startLiveScan() {
        guard state == .poweredOn else { return }
        devices.removeAll()
        onDevicesChange?(devices)
        scanning = true
        central.scanForPeripherals(withServices: nil,
                                   options: [CBCentralManagerScanOptionAllowDuplicatesKey: true])
    }

    func stopScan() {
        scanning = false
        if let w = waiter {
            waiter = nil
            w.cont.resume(returning: nil)
        }
        central.stopScan()
    }

    // MARK: 定点等待某台设备（重启进 OTA 后用）

    func scanFor(id: UUID, timeout: Double) async -> (CBPeripheral, String)? {
        await withCheckedContinuation { (c: CheckedContinuation<(CBPeripheral, String)?, Never>) in
            /* 整个动作丢回主队列：CBCentralManager 的 delegate 回调都在主队列，
               这样 waiter / scanning 不会被两个线程同时碰到。 */
            DispatchQueue.main.async { [weak self] in
                guard let self = self else {
                    c.resume(returning: nil)
                    return
                }
                self.scanning = false
                if let w = self.waiter {
                    self.waiter = nil
                    w.cont.resume(returning: nil)
                }
                self.central.stopScan()

                self.waiter = ScanWaiter(id: id, start: Date(), cont: c)
                self.central.scanForPeripherals(
                    withServices: nil,
                    options: [CBCentralManagerScanOptionAllowDuplicatesKey: true])
                DispatchQueue.main.asyncAfter(deadline: .now() + timeout) { [weak self] in
                    self?.endTargetedScan(nil)
                }
            }
        }
    }

    private func endTargetedScan(_ result: (CBPeripheral, String)?) {
        guard let w = waiter else { return }
        waiter = nil
        central.stopScan()
        w.cont.resume(returning: result)
    }

    // MARK: 会话

    func peripheral(for id: UUID) -> CBPeripheral? {
        if let p = peripheralCache[id] { return p }
        if let p = central.retrievePeripherals(withIdentifiers: [id]).first {
            peripheralCache[id] = p
            return p
        }
        return nil
    }

    func makeSession(_ p: CBPeripheral) -> BleSession {
        let s = BleSession(peripheral: p, central: central)
        sessions[p.identifier] = s
        return s
    }

    // MARK: CBCentralManagerDelegate

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        state = central.state
        if state != .poweredOn { scanning = false }
        onStateChange?(state)
    }

    func centralManager(_ central: CBCentralManager,
                        didDiscover peripheral: CBPeripheral,
                        advertisementData: [String: Any],
                        rssi RSSI: NSNumber) {
        let advName = (advertisementData[CBAdvertisementDataLocalNameKey] as? String) ?? ""
        let name = advName.isEmpty ? (peripheral.name ?? "") : advName
        peripheralCache[peripheral.identifier] = peripheral

        if let w = waiter {
            // iOS 会回放触发前的广播缓存（那时候还是普通固件的名字），先跳过
            if Date().timeIntervalSince(w.start) < 0.8 { return }
            if peripheral.identifier == w.id { endTargetedScan((peripheral, name)) }
            return
        }

        guard scanning, !name.isEmpty else { return }
        let rssi = RSSI.intValue
        guard rssi < 0 else { return }        // 127 = RSSI 不可用
        upsert(BleDevice(id: peripheral.identifier, name: name, rssi: rssi))
    }

    private func upsert(_ d: BleDevice) {
        if let i = devices.firstIndex(where: { $0.id == d.id }) {
            devices[i] = d
        } else {
            devices.append(d)
        }
        devices.sort { $0.rssi > $1.rssi }
        if devices.count > maxDevices { devices.removeLast(devices.count - maxDevices) }
        onDevicesChange?(devices)
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        sessions[peripheral.identifier]?.handleConnected()
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        sessions[peripheral.identifier]?.handleConnectFailed(error)
    }

    func centralManager(_ central: CBCentralManager,
                        didDisconnectPeripheral peripheral: CBPeripheral,
                        error: Error?) {
        /* 只在"真的断了"的时候上报。刚 cancel 掉又重新 connect 的那一小段里，
           旧的 disconnect 回调可能晚到，直接转发会把新会话误判成掉线。 */
        guard peripheral.state == .disconnected else { return }
        sessions[peripheral.identifier]?.handleDisconnected(error)
    }
}

// MARK: - 单个连接

final class BleSession: NSObject, CBPeripheralDelegate {

    let peripheral: CBPeripheral
    private weak var central: CBCentralManager?

    private(set) var linkLost: String?
    private(set) var maxWriteLength: Int = 20
    private var closed = false

    /// iOS 拿不到 MTU，按 maxWrite + 3 反推（只用于日志和分片计算）
    var mtu: Int { maxWriteLength + 3 }
    var shortId: String { String(peripheral.identifier.uuidString.prefix(8)) }

    private var connectWaiter: Waiter<Void>?
    private var discoverWaiter: Waiter<Void>?
    private var writeWaiter: Waiter<Void>?
    private var readWaiter: Waiter<[UInt8]>?
    private var readyWaiter: Waiter<Void>?

    private var pendingServices = 0

    init(peripheral: CBPeripheral, central: CBCentralManager) {
        self.peripheral = peripheral
        self.central = central
        super.init()
        peripheral.delegate = self
    }

    // MARK: 状态回调（由 BleCentral 转发）

    func handleConnected() {
        linkLost = nil
        connectWaiter?.resolve(.success(()))
        connectWaiter = nil
    }

    func handleConnectFailed(_ e: Error?) {
        connectWaiter?.resolve(.failure(
            OtaError("Connection failed: \(e?.localizedDescription ?? "unknown reason")")))
        connectWaiter = nil
    }

    func handleDisconnected(_ e: Error?) {
        if closed { return }
        let why = e?.localizedDescription ?? "peer disconnected"
        linkLost = "Connection lost (\(why))"
        let msg = linkLost ?? "Connection lost"
        connectWaiter?.resolve(.failure(OtaError(msg))); connectWaiter = nil
        writeWaiter?.resolve(.failure(OtaError(msg))); writeWaiter = nil
        readWaiter?.resolve(.success([])); readWaiter = nil
        readyWaiter?.resolve(.failure(OtaError(msg))); readyWaiter = nil
    }

    // MARK: 连接 / 发现

    func connect(timeout: Double = 8) async throws {
        closed = false
        linkLost = nil
        try await withCheckedThrowingContinuation { (c: CheckedContinuation<Void, Error>) in
            connectWaiter = Waiter(c, timeout: timeout,
                timeoutError: OtaError("Cannot connect within \(Int(timeout)) s "
                    + "(stale advertisement / device rebooting / too far)"))
            central?.connect(peripheral, options: nil)
        }
        /* iOS 没有 MTU 回调，连接建立后链路层自己换 MTU，maximumWriteValueLength
           要过一小会儿才更新。等 350 ms 再读，通常已经从 20 变成 182。 */
        try? await Task.sleep(nanoseconds: 350_000_000)
        maxWriteLength = peripheral.maximumWriteValueLength(for: .withoutResponse)
    }

    func discover(timeout: Double = 10) async throws {
        pendingServices = 0
        try await withCheckedThrowingContinuation { (c: CheckedContinuation<Void, Error>) in
            discoverWaiter = Waiter(c, timeout: timeout,
                timeoutError: OtaError("Service discovery failed (timeout)"))
            peripheral.discoverServices(nil)
        }
    }

    func characteristic(service: CBUUID, characteristic ch: CBUUID) -> CBCharacteristic? {
        guard let s = (peripheral.services ?? []).first(where: { $0.uuid == service }) else { return nil }
        return (s.characteristics ?? []).first(where: { $0.uuid == ch })
    }

    // MARK: 写 / 读

    /// 带响应写：天然同步点，也是唯一能确认"设备真的收到并写进 Flash"的方式。
    func write(_ data: [UInt8], to ch: CBCharacteristic, timeout: Double = 8) async throws {
        if let l = linkLost { throw OtaError(l) }
        try await withCheckedThrowingContinuation { (c: CheckedContinuation<Void, Error>) in
            writeWaiter = Waiter(c, timeout: timeout,
                timeoutError: OtaError("Write timeout (no write callback in \(Int(timeout)) s; "
                    + "the device may be erasing Flash or lost power)"))
            peripheral.writeValue(Data(data), for: ch, type: .withResponse)
        }
    }

    /// 无响应写：只把包交给协议栈。iOS 的流控是 canSendWriteWithoutResponse，
    /// 它翻 false 就等价于安卓那边的 "device busy / 缓冲区满"。
    func writeNoResponse(_ data: [UInt8], to ch: CBCharacteristic, timeout: Double = 8) async throws {
        if let l = linkLost { throw OtaError(l) }
        if !peripheral.canSendWriteWithoutResponse {
            try await withCheckedThrowingContinuation { (c: CheckedContinuation<Void, Error>) in
                readyWaiter = Waiter(c, timeout: timeout,
                    timeoutError: OtaError("Write buffer stayed full for \(Int(timeout)) s "
                        + "(the device is busy erasing Flash)"))
                // 装好 waiter 再查一次：可能刚好这一瞬间就绪，那样回调就不会再来了
                if peripheral.canSendWriteWithoutResponse { readyWaiter?.resolve(.success(())) }
            }
        }
        if let l = linkLost { throw OtaError(l) }
        peripheral.writeValue(Data(data), for: ch, type: .withoutResponse)
    }

    /// 回读 0xFEE1。失败/超时返回空数组（和安卓一致：让上层自己判长短）。
    func read(_ ch: CBCharacteristic, timeout: Double = 3) async -> [UInt8] {
        if linkLost != nil { return [] }
        do {
            return try await withCheckedThrowingContinuation { (c: CheckedContinuation<[UInt8], Error>) in
                readWaiter = Waiter(c, timeout: timeout, timeoutError: OtaError("read timeout"))
                peripheral.readValue(for: ch)
            }
        } catch {
            return []
        }
    }

    /// 给协议栈一点时间把发送队列排空；真正的确认交给带响应 VERIFY。
    func drainWindow() async throws {
        try? await Task.sleep(nanoseconds: 80_000_000)
        if let l = linkLost { throw OtaError(l) }
    }

    func close() {
        closed = true
        connectWaiter?.resolve(.failure(OtaError("closed"))); connectWaiter = nil
        discoverWaiter?.resolve(.failure(OtaError("closed"))); discoverWaiter = nil
        writeWaiter?.resolve(.failure(OtaError("closed"))); writeWaiter = nil
        readWaiter?.resolve(.success([])); readWaiter = nil
        readyWaiter?.resolve(.failure(OtaError("closed"))); readyWaiter = nil
        peripheral.delegate = nil
        central?.cancelPeripheralConnection(peripheral)
    }

    // MARK: CBPeripheralDelegate

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let e = error {
            discoverWaiter?.resolve(.failure(
                OtaError("Service discovery failed: \(e.localizedDescription)")))
            discoverWaiter = nil
            return
        }
        let svcs = peripheral.services ?? []
        if svcs.isEmpty {
            discoverWaiter?.resolve(.success(()))
            discoverWaiter = nil
            return
        }
        pendingServices = svcs.count
        for s in svcs { peripheral.discoverCharacteristics(nil, for: s) }
    }

    func peripheral(_ peripheral: CBPeripheral,
                    didDiscoverCharacteristicsFor service: CBService,
                    error: Error?) {
        pendingServices -= 1
        if pendingServices <= 0 {
            discoverWaiter?.resolve(.success(()))
            discoverWaiter = nil
        }
    }

    func peripheral(_ peripheral: CBPeripheral,
                    didWriteValueFor characteristic: CBCharacteristic,
                    error: Error?) {
        if let e = error {
            writeWaiter?.resolve(.failure(OtaError("Write failed: \(e.localizedDescription)")))
        } else {
            writeWaiter?.resolve(.success(()))
        }
        writeWaiter = nil
    }

    func peripheral(_ peripheral: CBPeripheral,
                    didUpdateValueFor characteristic: CBCharacteristic,
                    error: Error?) {
        let v = (error == nil) ? [UInt8](characteristic.value ?? Data()) : [UInt8]()
        readWaiter?.resolve(.success(v))
        readWaiter = nil
    }

    func peripheralIsReady(toSendWriteWithoutResponse peripheral: CBPeripheral) {
        readyWaiter?.resolve(.success(()))
        readyWaiter = nil
    }
}
