//
//  FotaEngine.swift
//  LRF OTA Updater (iOS)
//
//  沁恒 OnlyUpdateApp OTA 客户端 —— 与安卓 OtaManager.upgrade() 逐条对应。
//
//  协议（全部对着 IAP 源码 / 反汇编核对过）：
//    - 服务 0xFEE0，通道 0xFEE1。只有 READ / WRITE，**没有 CCCD**，
//      所以每发一条命令都要"回读 0xFEE1"取结果，而不是等通知。
//    - 0x80 编程：cmd + len + addrL + addrH + data，addr = 实际地址 / 16
//    - 0x81 擦除：cmd + 04 + addrL + addrH + numL + numH，num = 4 KB 块数
//      （异步，回包迟）
//    - 0x82 校验：同 0x80 的格式
//    - 0x83 结束：置 ImageFlag=A 并跳 APP
//    - 0x84 信息：回 20 字节 —— 第 1 字节=2，第 2~5 字节=分区上限(0x3C000)，
//      第 6~7 字节=块大小(4096)，第 8~9 字节=CHIP_ID
//    - 状态回包统一 2 字节：status + 0，status=0 表示成功
//
//  普通固件（服务 0xFFE0 / 通道 0xFFE3）写 1 个字节 → 设备重启进 OTA。
//

import Foundation
import CoreBluetooth

@MainActor
final class FotaEngine {

    struct Sink {
        let stage: (String) -> Void
        let log: (String) -> Void
        let progress: (Int, String) -> Void
    }

    private let ble: BleCentral

    init(_ ble: BleCentral) {
        self.ble = ble
    }

    private func hx(_ v: Int) -> String {
        String(format: "%X", UInt32(truncatingIfNeeded: v))
    }

    // MARK: - 升级主流程

    func upgrade(peripheral: CBPeripheral,
                 firmware fw: Firmware,
                 verify: Bool,
                 sink: Sink) async throws {

        /* 把要发的内容先亮出来：两次 OTA 的 CRC 一对比，
           立刻就能看出"发过去的还是旧文件"。 */
        sink.log("Firmware \(fw.name) [\(fw.source)] 0x\(hx(fw.base))~0x\(hx(fw.end))  "
            + "\(fw.size) B  " + String(format: "CRC32=%08X", fw.crc32)
            + "  entry \(fw.entry)  " + String(format: "ImageFlag=0x%X", fw.imageFlag))
        if !fw.iapNote.isEmpty { sink.log(fw.iapNote) }

        guard fw.inAppRegion else {
            throw OtaError("Firmware address 0x\(hx(fw.base))~0x\(hx(fw.end)) is outside "
                + "Image A (0x\(hx(Firmware.appStart))~0x\(hx(Firmware.appLimit)))")
        }

        var session = try await openSession(peripheral, sink: sink)
        defer { session.close() }

        sink.log("Connected to \(session.shortId), max write \(session.maxWriteLength) B "
            + "(MTU ~\(session.mtu))")
        var chr = session.characteristic(service: BleUUID.otaService, characteristic: BleUUID.otaChar)

        if chr == nil {
            // 还跑在普通固件里 —— 写 0xFFE3 让它跳 IAP
            guard let a3 = session.characteristic(service: BleUUID.appService,
                                                  characteristic: BleUUID.appChar3) else {
                throw OtaError("Neither 0xFEE0 nor 0xFFE3 is present - not a supported device")
            }
            sink.stage("Switching the device into OTA...")
            _ = try? await session.write([0x01], to: a3)
            sink.log("0xFFE3 written, the device reboots now")

            let id = session.peripheral.identifier
            session.close()
            try? await Task.sleep(nanoseconds: 1_500_000_000)

            sink.stage("Waiting for the device to advertise in OTA mode...")
            session = try await waitForOtaSession(id: id, total: 90, sink: sink)
            sink.log("OTA connected, max write \(session.maxWriteLength) B (MTU ~\(session.mtu))")
            chr = session.characteristic(service: BleUUID.otaService, characteristic: BleUUID.otaChar)
        }

        guard let ch = chr else { throw OtaError("OTA channel 0xFEE1 not found") }

        // ---- 0x84 读设备信息
        let info = try await cmd(session, ch, [0x84, 0x00], minLen: 20, sink: sink)
        let limit = info.count >= 5 ? Int(info.le32(1)) : Firmware.appLimit
        let blkRaw = info.count >= 7 ? Int(info.le16(5)) : 0
        let blk = blkRaw == 0 ? 4096 : blkRaw
        let chip = info.count >= 9 ? info.le16(7) : 0
        sink.log("Device info: partition limit 0x\(hx(limit)), block \(blk) B, "
            + "CHIP_ID 0x" + String(format: "%04X", chip))
        if fw.end > limit {
            throw OtaError("Firmware end 0x\(hx(fw.end)) exceeds the partition limit 0x\(hx(limit))")
        }

        // ---- 0x81 擦除
        let start = fw.base
        let blocks = (fw.end - start + blk - 1) / blk
        sink.stage("Erasing \(blocks) blocks from 0x\(hx(start))...")
        let er = await erase(session, ch, start: start, blocks: blocks,
                             timeoutMs: Double(blocks) * 45 + 4000)
        if er.isEmpty || er[0] != 0 {
            let st = er.isEmpty ? "no reply" : "status=0x" + String(format: "%02X", er[0])
            throw OtaError("Erase failed, \(st)")
        }
        sink.log("Erase complete")

        // ---- 0x80 编程
        /* 分片按 16 字节对齐（IAP 用地址/16 寻址，长度最好也是 16 的倍数）。
           iOS 的 maximumWriteValueLength 已经把 ATT 头去掉了，所以这里
           直接拿它减 4 字节命令头。185 的 MTU → 182 → 每包 176 字节。 */
        let chunk = Swift.min(Swift.max(((session.maxWriteLength - 4) / 16) * 16, 16), 240)
        let total = fw.size
        var fast = !verify
        sink.log("Chunk \(chunk) bytes (max write \(session.maxWriteLength) B, "
            + (fast ? "write without response" : "verify every packet") + ")")
        if chunk < 100 {
            sink.log("Note: the link allows only \(session.maxWriteLength) B per packet, "
                + "the transfer will be slow")
        }
        sink.stage("Writing...")

        /* 试探：先发第一包看链路是否可用。iOS 的无响应写没有回调，
           只能靠 canSendWriteWithoutResponse 判断，出问题立刻退回逐包模式。
           第一包重发一次是安全的（同地址同数据）。 */
        if fast && total > 0 {
            do {
                let n = Swift.min(chunk, total)
                try await session.writeNoResponse(
                    packet(fw, addr: start, offset: 0, n: n), to: ch)
                try await session.drainWindow()
            } catch {
                fast = false
                sink.log("Note: write-without-response is unusable "
                    + "(\(error.localizedDescription)), switching to per-packet mode")
            }
        }

        var off = 0
        var sinceBarrier = 0
        var lastPct = -1
        let t0 = Date()

        while off < total {
            let n = Swift.min(chunk, total - off)
            let addr = start + off
            let pkt = packet(fw, addr: addr, offset: off, n: n)

            if fast {
                try await session.writeNoResponse(pkt, to: ch)
                /* 节流：IAP 收到一包就在协议栈回调里同步写一次 Flash，
                   连发太猛会把发送队列灌满。每包让 1 ms，每 8 包让 2 ms。 */
                if (sinceBarrier & 7) == 0 {
                    try? await Task.sleep(nanoseconds: 2_000_000)
                } else {
                    try? await Task.sleep(nanoseconds: 1_000_000)
                }
                sinceBarrier += 1
                if sinceBarrier >= 32 {
                    sinceBarrier = 0
                    sink.log("Sent \(off + n) / \(total) B, waiting for the device...")
                    try await session.drainWindow()          // 让队列排空
                    try? await Task.sleep(nanoseconds: 50_000_000)
                    var vp = pkt                            // 带响应校验，天然同步点
                    vp[0] = 0x82
                    try await session.write(vp, to: ch)
                    let vr = await session.read(ch)
                    if vr.isEmpty {
                        throw OtaError("Verify failed @0x\(hx(addr)): no reply")
                    }
                    if vr[0] != 0 {
                        throw OtaError("Verify failed @0x\(hx(addr)), status=0x"
                            + String(format: "%02X", vr[0]))
                    }
                }
            } else {
                let r = try await cmd(session, ch, pkt, minLen: 1, sink: sink)
                if r[0] != 0 {
                    throw OtaError("Write failed @0x\(hx(addr)), status=0x"
                        + String(format: "%02X", r[0]))
                }
                if verify {
                    var vp = pkt
                    vp[0] = 0x82
                    let vr = try await cmd(session, ch, vp, minLen: 1, sink: sink)
                    if vr[0] != 0 {
                        throw OtaError("Verify failed @0x\(hx(addr)), status=0x"
                            + String(format: "%02X", vr[0]))
                    }
                }
            }

            off += n
            let pct = Swift.min(Swift.max(Int(Int64(off) * 100 / Int64(total)), 0), 100)
            if pct != lastPct {
                lastPct = pct
                let sec = Swift.max(Date().timeIntervalSince(t0), 0.1)
                let kbs = Double(off) / 1024.0 / sec
                sink.progress(pct, "\(off) / \(total) B   0x\(hx(addr))   "
                    + String(format: "%.0f", kbs) + " KB/s")
            }
        }
        if fast { try await session.drainWindow() }     // 收尾：确认最后一批也发出去了

        // ---- 0x83 结束
        sink.stage("Writing the end marker...")
        _ = try? await session.write([0x83, 0x00], to: ch)
        try? await Task.sleep(nanoseconds: 800_000_000)
        sink.progress(100, "Done")
        sink.stage("Upgrade complete: the device sets ImageFlag back to A "
            + "and jumps to the new firmware")
    }

    private func packet(_ fw: Firmware, addr: Int, offset: Int, n: Int) -> [UInt8] {
        let a16 = addr / 16
        var p = [UInt8](repeating: 0, count: 4 + n)
        p[0] = 0x80
        p[1] = UInt8(n & 0xFF)
        p[2] = UInt8(a16 & 0xFF)
        p[3] = UInt8((a16 >> 8) & 0xFF)
        p.replaceSubrange(4 ..< (4 + n), with: fw.bytes[offset ..< (offset + n)])
        return p
    }

    // MARK: - 底层命令

    /// 发命令 → 回读 0xFEE1，失败重试 3 次。
    private func cmd(_ s: BleSession, _ ch: CBCharacteristic, _ pkt: [UInt8],
                     minLen: Int, sink: Sink) async throws -> [UInt8] {
        var last = "unknown"
        for _ in 1 ... 3 {
            do {
                try await s.write(pkt, to: ch)
                let r = await s.read(ch)
                if r.count >= minLen { return r }
                last = "reply is only \(r.count) bytes"
            } catch {
                last = error.localizedDescription
                try? await Task.sleep(nanoseconds: 150_000_000)
            }
        }
        throw OtaError("Command 0x" + String(format: "%02X", pkt[0]) + " failed: " + last)
    }

    /// 擦除是异步的（设备一个 TMOS 事件擦一块），回包会晚。
    /// 起手先按块数等一段时间，再轮询：上一条回包是 INFO 的 20 字节，
    /// 一旦读回 2 字节就说明擦除结束、状态回来了。
    private func erase(_ s: BleSession, _ ch: CBCharacteristic, start: Int, blocks: Int,
                       timeoutMs: Double) async -> [UInt8] {
        let a16 = start / 16
        let pkt: [UInt8] = [0x81, 4,
                            UInt8(a16 & 0xFF), UInt8((a16 >> 8) & 0xFF),
                            UInt8(blocks & 0xFF), UInt8((blocks >> 8) & 0xFF)]
        do { try await s.write(pkt, to: ch) } catch { return [] }

        try? await Task.sleep(nanoseconds: UInt64(blocks) * 25_000_000 + 200_000_000)
        let deadline = Date().addingTimeInterval(timeoutMs / 1000.0)
        while Date() < deadline {
            let r = await s.read(ch)
            if r.count == 2 { return r }
            try? await Task.sleep(nanoseconds: 120_000_000)
        }
        return []
    }

    /// 连接 + 发现服务，最多试 5 次（设备刚重启时偶尔会拒一次）。
    private func openSession(_ p: CBPeripheral, sink: Sink) async throws -> BleSession {
        var lastMsg = "unknown"
        for i in 1 ... 5 {
            let sid = String(p.identifier.uuidString.prefix(8))
            sink.stage("Connecting to \(sid)... (attempt \(i))")
            let s = ble.makeSession(p)
            do {
                try await s.connect()
                try await s.discover()
                return s
            } catch {
                lastMsg = error.localizedDescription
                s.close()
                if i < 5 {
                    sink.log("Connection failed: \(lastMsg), retrying...")
                    try? await Task.sleep(nanoseconds: 1_200_000_000)
                }
            }
        }
        throw OtaError("Cannot connect: \(lastMsg)")
    }

    /// 设备重启后，一直等到真正连上 OTA 服务（0xFEE0）为止。
    /// 刚触发时 iOS 的扫描缓存里还会回放"普通固件"那条记录，
    /// 所以必须校验服务，不能扫到同一个 identifier 就认为成功。
    private func waitForOtaSession(id: UUID, total: Double, sink: Sink) async throws -> BleSession {
        let deadline = Date().addingTimeInterval(total)
        let otaPrefix = "OTAOTA"
        var lastErr = "This device cannot be found"
        var bounce = 0          // 触发后又被弹回普通固件的次数
        var appSeen = 0         // 连续几次扫到"still in the APP"的广播

        while Date() < deadline {
            guard let (per, name) = await ble.scanFor(id: id, timeout: 6) else {
                lastErr = "This device cannot be found"
                continue
            }

            /* 广播里的名字最可靠。IAP 广播的是 OTAOTA_OTAOTA_OTA，
               普通固件是 FIRE8000-… */
            if !name.isEmpty && !name.uppercased().hasPrefix(otaPrefix) {
                appSeen += 1
                sink.log("Found \(name) (not in OTA yet), still waiting... (\(appSeen))")
                /* 这里以前会直接开连，结果一头撞在设备重启窗口里，
                   连接立刻失败，重试全废。现在光看广播名就知道它还在 APP，
                   先不连，等它跳过去。连续 3 次（约 12 秒）都还在 APP，
                   说明 0xFFE3 没生效（APP 正忙 / 半截程序），那就连上去补写一次。 */
                if appSeen >= 3 {
                    appSeen = 0
                    if let s = try? await openSession(per, sink: sink) {
                        if let a3 = s.characteristic(service: BleUUID.appService,
                                                     characteristic: BleUUID.appChar3) {
                            _ = try? await s.write([0x01], to: a3)
                            sink.log("Still in the APP, writing 0xFFE3 once more...")
                        }
                        s.close()
                    }
                    try? await Task.sleep(nanoseconds: 1_500_000_000)
                } else {
                    try? await Task.sleep(nanoseconds: 600_000_000)
                }
                continue
            }

            var opened: BleSession?
            do {
                opened = try await openSession(per, sink: sink)
            } catch {
                lastErr = error.localizedDescription
                continue
            }
            guard let s = opened else { continue }

            if s.characteristic(service: BleUUID.otaService, characteristic: BleUUID.otaChar) != nil {
                return s
            }

            // 连上的还是普通固件：可能是没重启完，也可能是老 IAP 立刻把控制权弹回 APP
            if let a3 = s.characteristic(service: BleUUID.appService,
                                         characteristic: BleUUID.appChar3) {
                bounce += 1
                if bounce >= 2 {
                    s.close()
                    throw OtaError("The IAP bounced the device back to normal firmware "
                        + "(\(bounce) times in a row). This is the new APP + old 2024 IAP deadlock: "
                        + "the old IAP calls jumpApp() on a non-soft-reset with ImageFlag=3, "
                        + "so Bluetooth never starts. The phone cannot change the IAP "
                        + "(OTA erase stops at 0x3C000, the IAP sits above it). "
                        + "Use [Repair build] on the main screen: choose the full-chip .bin, "
                        + "let the app swap in the new IAP, then flash the whole chip over USB once.")
                }
                sink.log("Bounced back to the APP after trigger #\(bounce), "
                    + "writing 0xFFE3 again...")
                _ = try? await s.write([0x01], to: a3)
            }
            lastErr = "Connected to normal firmware, the reboot is not finished"
            s.close()
            try? await Task.sleep(nanoseconds: 800_000_000)
        }
        throw OtaError("OTA mode never appeared: \(lastErr)")
    }
}
