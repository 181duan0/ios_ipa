//
//  IapRepair.swift
//  LRF OTA Updater (iOS)
//
//  「适配版」救援工具 —— 与安卓 IapRepair.kt 一致。
//
//  设备里如果是「新版 APP（不复位直跳 0x3C000）+ 2024 老 IAP」的混搭，
//  老 IAP 会在非软复位时直接 jumpApp() 弹回 APP，手机永远扫不到 OTA 服务。
//  这个死锁在固件里，BLE 侧改不了（擦除上限 0x3C000，IAP 在 0x3C000 以上，
//  DataFlash 0x7000 也没有对手机开放的写通道），必须整片烧一次。
//
//  所以 App 能做的是把这一步缩到最短：内置配套的新 IAP，自动把用户选的
//  整片 bin 里的老 IAP 换掉、导出成可直接整片烧录的 .bin。
//

import Foundation

enum IapRepair {

    static let iapOffset = 0x3C000
    static let iapSize = 0x4000        // 16 KB

    private static let newEntry: [UInt8] = [0x6F, 0x00, 0x40, 0x7B]   // j 0x3C7B0（新）
    private static let oldEntry: [UInt8] = [0x6F, 0x00, 0xC0, 0x76]   // j 0x3C76C（老）

    struct Info {
        let fullChip: Bool
        let iapState: String
        let oldIap: Bool
        let entry: String
        let appCrc: UInt32
        let appBytes: Int
    }

    /// 头 4 KB 是 JumpIAP 或填充，0x1000 才是 APP —— 判定整片镜像
    private static func isFullChip(_ raw: [UInt8]) -> Bool {
        if raw.count >= 4 && Array(raw[0 ..< 4]) == [0x6F, 0xC0, 0x03, 0x00] { return true }
        if raw.count < 0x1004 { return false }
        for i in 0 ..< 0x1000 where raw[i] != 0x00 && raw[i] != 0xFF { return false }
        return raw[0x1000] == 0x6F || raw[0x1000] == 0x2F
    }

    static func inspect(_ raw: [UInt8]) -> Info {
        let full = isFullChip(raw)
        var entry = "--"
        var state = "Not a full-chip image (APP only, no IAP involved)"
        var old = false

        if full && raw.count > iapOffset + 4 {
            let e = Array(raw[iapOffset ..< iapOffset + 4])
            entry = String(format: "%02X %02X %02X %02X", e[0], e[1], e[2], e[3])
            old = (e == oldEntry)
            if e == newEntry {
                state = "New IAP (matches this APP)"
            } else if old {
                state = "Old IAP (blocks the device from entering OTA)"
            } else {
                state = "Unknown IAP (replace it)"
            }
        }

        let a: [UInt8] = full
            ? Array(raw[0x1000 ..< min(raw.count, iapOffset)])
            : raw
        var n = a.count
        while n > 1 && a[n - 1] == 0xFF { n -= 1 }
        let app = Array(a[0 ..< n])
        return Info(fullChip: full, iapState: state, oldIap: old, entry: entry,
                    appCrc: CRC32.checksum(app), appBytes: n)
    }

    /// App 内置的新 IAP（0x3C000~0x3FFFF，16 KB）
    static func builtinIap() throws -> [UInt8] {
        guard let u = Bundle.main.url(forResource: "iap_new", withExtension: "bin") else {
            throw OtaError("Bundled iap_new.bin is missing from the app")
        }
        let d = try Data(contentsOf: u)
        guard d.count >= iapSize else {
            throw OtaError("Bundled iap_new.bin is only \(d.count) bytes, expected \(iapSize)")
        }
        return [UInt8](d.prefix(iapSize))
    }

    /// 把整片镜像的 IAP 区换成内置新 IAP；APP / JumpIAP / 0x40000 库区一律不动。
    /// 非整片镜像（纯 APP）不允许修，直接抛错，避免误把 APP 当整片。
    static func repair(_ raw: [UInt8]) throws -> [UInt8] {
        let info = inspect(raw)
        if !info.fullChip {
            throw OtaError("This is not a full-chip image (no JumpIAP at 0x0), no IAP swap needed")
        }
        if raw.count < iapOffset + iapSize {
            throw OtaError("Full-chip image is shorter than 0x40000 bytes; "
                + "it may not come from the merge tool")
        }
        let iap = try builtinIap()
        var out = raw
        out.replaceSubrange(iapOffset ..< (iapOffset + iapSize), with: iap)
        return out
    }

    /// 读文件（fileImporter 给的是安全作用域 URL）
    static func read(url: URL) throws -> [UInt8] {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            return [UInt8](try Data(contentsOf: url))
        } catch {
            throw OtaError("Cannot open this file (\(error.localizedDescription))")
        }
    }

    /// 写到 App 的 Documents 目录 —— Info.plist 里开了 UIFileSharingEnabled，
    /// 所以「文件」App 的 "我的 iPhone / LRF OTA" 里能直接看到并拷走。
    @discardableResult
    static func export(_ data: [UInt8], name: String) throws -> URL {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let u = dir.appendingPathComponent(name)
        do {
            try Data(data).write(to: u, options: .atomic)
        } catch {
            throw OtaError("Cannot write \(name): \(error.localizedDescription)")
        }
        return u
    }
}
