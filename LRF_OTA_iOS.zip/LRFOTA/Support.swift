//
//  Support.swift
//  LRF OTA Updater (iOS)
//
//  公共小工具：错误类型、一次性 continuation 包装、CRC32。
//

import Foundation

/// 统一的错误载体。message 直接上屏，所以文案按安卓端保持一致（英文）。
struct OtaError: LocalizedError {
    let message: String
    init(_ m: String) { message = m }
    var errorDescription: String? { message }
}

/// 一次性的 continuation 包装。
///
/// CoreBluetooth 的回调是异步的：可能成功、可能失败、也可能永远不来。
/// 这里把三件事收在一起：
///   1. 只允许 resolve 一次（重复 resume 会直接崩进程）；
///   2. 自带超时 —— 超时只是"用失败的结果提前 resolve"，之后真回调来了
///      会被 done 标记挡掉。这样不需要 TaskGroup，也不会有"等一个永远
///      不来的 continuation"导致的死锁；
///   3. 加锁，允许从任意线程 resolve（实际都在 main）。
final class Waiter<T> {
    private var continuation: CheckedContinuation<T, Error>?
    private let lock = NSLock()
    private var done = false

    init(_ c: CheckedContinuation<T, Error>, timeout: Double = 0, timeoutError: Error? = nil) {
        continuation = c
        if timeout > 0, let te = timeoutError {
            DispatchQueue.main.asyncAfter(deadline: .now() + timeout) { [weak self] in
                self?.resolve(.failure(te))
            }
        }
    }

    func resolve(_ r: Result<T, Error>) {
        lock.lock()
        if done { lock.unlock(); return }
        done = true
        let c = continuation
        continuation = nil
        lock.unlock()
        c?.resume(with: r)
    }

    var isDone: Bool {
        lock.lock(); defer { lock.unlock() }
        return done
    }
}

/// CRC-32 (IEEE 802.3, 反射, 多项式 0xEDB88320, 初值/终值异或 0xFFFFFFFF)。
/// 和安卓端 java.util.zip.CRC32 完全一致，两边的 CRC32 可以直接对比。
enum CRC32 {
    private static let table: [UInt32] = {
        var t = [UInt32](repeating: 0, count: 256)
        for i in 0 ..< 256 {
            var c = UInt32(i)
            for _ in 0 ..< 8 {
                c = (c & 1) != 0 ? (0xEDB8_8320 ^ (c >> 1)) : (c >> 1)
            }
            t[i] = c
        }
        return t
    }()

    static func checksum(_ bytes: [UInt8]) -> UInt32 {
        var crc: UInt32 = 0xFFFF_FFFF
        for b in bytes {
            crc = table[Int((crc ^ UInt32(b)) & 0xFF)] ^ (crc >> 8)
        }
        return crc ^ 0xFFFF_FFFF
    }
}

extension Array where Element == UInt8 {
    /// 小端 16 位
    func le16(_ off: Int) -> UInt16 {
        guard off + 1 < count else { return 0 }
        return UInt16(self[off]) | (UInt16(self[off + 1]) << 8)
    }

    /// 小端 32 位
    func le32(_ off: Int) -> UInt32 {
        guard off + 3 < count else { return 0 }
        return UInt32(self[off])
            | (UInt32(self[off + 1]) << 8)
            | (UInt32(self[off + 2]) << 16)
            | (UInt32(self[off + 3]) << 24)
    }
}

/// 把秒数变成 "0.8 s" 这种，日志里用
func secs(_ ns: UInt64) -> String {
    String(format: "%.1f s", Double(ns) / 1_000_000_000.0)
}
