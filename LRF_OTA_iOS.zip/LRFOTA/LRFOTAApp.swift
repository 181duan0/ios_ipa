//
//  LRFOTAApp.swift
//  LRF OTA Updater (iOS)
//

import SwiftUI

@main
struct LRFOTAApp: App {
    @StateObject private var model = AppModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(model)
        }
    }
}
