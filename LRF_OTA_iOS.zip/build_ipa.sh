#!/bin/bash
#
# 在 Mac 上一条命令出未签名 IPA。
# 用法：双击或在终端执行  ./build_ipa.sh
#
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v xcodegen >/dev/null 2>&1; then
  if command -v brew >/dev/null 2>&1; then
    echo ">> 安装 XcodeGen ..."
    brew install xcodegen
  else
    echo "!! 没找到 Homebrew。请先装 Homebrew（https://brew.sh），"
    echo "   或者手工安装 XcodeGen（https://github.com/yonaskolb/XcodeGen）后重跑。"
    exit 1
  fi
fi

echo ">> 生成 LRFOTA.xcodeproj"
xcodegen generate

echo ">> 编译（不签名）"
rm -rf build Payload LRFOTA.ipa
xcodebuild -project LRFOTA.xcodeproj \
           -scheme LRFOTA \
           -configuration Release \
           -sdk iphoneos \
           -derivedDataPath build \
           CODE_SIGN_IDENTITY="" \
           CODE_SIGNING_REQUIRED=NO \
           CODE_SIGNING_ALLOWED=NO \
           build

APP="build/Build/Products/Release-iphoneos/LRFOTA.app"
if [ ! -d "$APP" ]; then
  echo "!! 编译产物不存在：$APP"
  exit 1
fi

echo ">> 打包成 IPA"
mkdir -p Payload
cp -R "$APP" Payload/
zip -qry LRFOTA.ipa Payload
rm -rf Payload

echo
echo "OK -> $(pwd)/LRFOTA.ipa  ($(du -h LRFOTA.ipa | cut -f1))"
echo "下一步：把 LRFOTA.ipa 导入全能签，用证书签名后安装。"
